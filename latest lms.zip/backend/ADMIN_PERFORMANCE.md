# Admin panel performance

## What was slowing it down

- **Sidebar “beeps” (badges)** – Every admin page load ran **11 database count queries** (pending courses, bundles, webinars, reviews, comments, payouts, offline payments, etc.). This is now cached for **90 seconds** so most requests use cache instead of hitting the DB.

## What we changed

1. **`AdminAuthenticate`** – Sidebar beeps are stored in cache key `admin_sidebar_beeps` (90s TTL). When you approve/reject a payout or offline payment, that cache is cleared so the sidebar updates quickly.
2. **PayoutController / OfflinePaymentController** – After status updates, they call `Cache::forget('admin_sidebar_beeps')`.

## Optional: make it even faster

1. **Config and route cache** (recommended on production / when not changing routes or config often):
   ```bash
   php artisan config:cache
   php artisan route:cache
   ```
   After changing `.env` or routes, run:
   ```bash
   php artisan config:clear
   php artisan route:clear
   ```

2. **Faster cache/session** – If you have Redis:
   - In `.env`: `CACHE_DRIVER=redis`, `SESSION_DRIVER=redis`
   - Speeds up settings and sidebar cache, and session reads.

3. **Keep `APP_DEBUG=false`** – Debug mode adds overhead; your `.env` already has it off.
