<?php

namespace App\Http\Controllers\Api\Config;

use App\Api\Request;
use App\Http\Controllers\Controller;
use App\Models\PaymentChannel;

class ConfigController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function list(Request $request)
    {
        return self::get();
    }

    public static function get()
    {
        $registerMethod = getGeneralSettings('register_method') ?? 'email';
        $userLanguages = getGeneralSettings('user_languages');
        if (!empty($userLanguages) and is_array($userLanguages)) {
            $userLanguages = getLanguages($userLanguages);
        } else {
            $userLanguages = [];
        }
        $paymentChannels = PaymentChannel::all()->groupBy('status');
        $financialSettings = getFinancialSettings();
        $getFinancialSettings = $financialSettings['minimum_payout'] ?? 0;
        $currencySettings = getFinancialCurrencySettings() ?? [];
        $currency = [
            'sign' => currencySign(),
            'name' => currency()
        ];

        $features = getFeaturesSettings();
        $referralSettings = getReferralSettings();

        $data = [
            'register_method' => $registerMethod,
            'offline_bank_account' => getOfflineBanksTitle() ?? null,
            'user_language' => $userLanguages,
            'payment_channels' => $paymentChannels,
            'minimum_payout_amount' => $getFinancialSettings,
            'currency' => $currency,
            'currency_position' => getFinancialSettings('currency_position') ?? 'before',
            'currency_decimal' => $currencySettings['currency_decimal'] ?? 0,
            'price_display' => getFinancialSettings('price_display') ?? 'only_price',
            'show_google_login_button' => !empty($features['google_login_status']),
            'show_facebook_login_button' => !empty($features['facebook_login_status']),
            'showOtherRegisterMethod' => (bool) (getGeneralSettings('show_other_register_method') ?? false),
            'selectRolesDuringRegistration' => ['user', 'teacher', 'organization'],
            'referralSettings' => [
                'status' => !empty($referralSettings['referral'] ?? false),
            ],
        ];
        return response()->json(['data' => $data]);
    }

    /**
     * Register config per role (user, teacher, organization).
     * App may use this to get custom fields for the registration form.
     */
    public function registerConfig($role)
    {
        $allowed = ['user', 'teacher', 'organization'];
        if (!in_array($role, $allowed)) {
            return response()->json(['data' => ['fields' => []]], 200);
        }
        $data = ['role' => $role, 'fields' => []];
        return response()->json(['data' => $data]);
    }


}
