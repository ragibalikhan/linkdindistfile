/**
 * Instructor course batches API (panel).
 */
import { api, requestRaw } from "@/lib/api";
import { paths } from "@/constants/api-paths";
import type { CourseBatch, WebinarBrief } from "@/types/api";

/** GET panel/classes returns { my_classes, purchases, ... } (plain or inside data). */
export const instructorCoursesService = {
  getMyClasses: () =>
    requestRaw<{ my_classes?: WebinarBrief[]; data?: { my_classes?: WebinarBrief[] } }>(paths.panel.classes).then(
      (res) =>
        (res?.data?.my_classes ?? (res && "my_classes" in res ? (res as { my_classes: WebinarBrief[] }).my_classes : undefined)) ?? []
    ),
};

export const batchesService = {
  list: (webinarId: number | string) =>
    api
      .get<{ batches?: CourseBatch[] }>(paths.panel.batches(webinarId))
      .then((res) => res?.batches ?? []),

  create: (webinarId: number | string, body: BatchPayload) =>
    api
      .post<{ batch?: CourseBatch }>(paths.panel.batches(webinarId), body)
      .then((res) => res?.batch),

  update: (webinarId: number | string, batchId: number | string, body: BatchPayload) =>
    api
      .put<{ batch?: CourseBatch }>(paths.panel.batch(webinarId, batchId), body)
      .then((res) => res?.batch),

  delete: (webinarId: number | string, batchId: number | string) =>
    api.delete(paths.panel.batch(webinarId, batchId)),
};

export interface BatchPayload {
  name: string;
  code?: string;
  start_date?: number | null;
  end_date?: number | null;
  capacity?: number | null;
  status: string;
  sort_order?: number;
}
