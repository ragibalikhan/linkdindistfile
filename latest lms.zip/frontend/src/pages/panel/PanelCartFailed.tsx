import { useSearchParams, Link } from "react-router-dom";
import { XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PanelCartFailed() {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get("order_id");

  return (
    <>
      <div className="flex flex-col items-center justify-center py-16 text-center max-w-md mx-auto">
        <XCircle className="h-16 w-16 text-destructive mb-6" />
        <h1 className="text-2xl font-display font-bold text-foreground mb-2">Payment failed</h1>
        <p className="text-muted-foreground mb-6">
          {orderId ? `Payment for order #${orderId} could not be completed.` : "Payment could not be completed."}
        </p>
        <div className="flex gap-3">
          <Link to="/panel/cart">
            <Button variant="outline">Back to cart</Button>
          </Link>
          <Link to="/panel">
            <Button>Go to dashboard</Button>
          </Link>
        </div>
      </div>
    </>
  );
}
