import { useSearchParams, Link } from "react-router-dom";
import { CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PanelCartSuccess() {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get("order_id");

  return (
    <>
      <div className="flex flex-col items-center justify-center py-16 text-center max-w-md mx-auto">
        <CheckCircle className="h-16 w-16 text-green-600 mb-6" />
        <h1 className="text-2xl font-display font-bold text-foreground mb-2">Payment successful</h1>
        <p className="text-muted-foreground mb-6">
          {orderId ? `Your order #${orderId} has been confirmed.` : "Your order has been confirmed."}
        </p>
        <Link to="/panel">
          <Button className="bg-gradient-cta">Go to dashboard</Button>
        </Link>
      </div>
    </>
  );
}
