#!/bin/bash
# AWS EC2 Deployment Script for Rocket LMS Backend
# Usage: ./deploy.sh

set -e

echo "🚀 Starting Rocket LMS Backend Deployment..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo -e "${RED}❌ Docker is not installed. Please install Docker first.${NC}"
    exit 1
fi

# Check if .env exists
if [ ! -f .env ]; then
    echo -e "${YELLOW}⚠️  .env file not found. Creating from .env.example...${NC}"
    cp .env.example .env
    echo -e "${YELLOW}⚠️  Please edit .env file and set your configuration, then run this script again.${NC}"
    exit 1
fi

# Check if APP_KEY is set
if ! grep -q "APP_KEY=base64:" .env; then
    echo -e "${YELLOW}⚠️  APP_KEY not set. Generating...${NC}"
    docker run --rm -v $(pwd):/app -w /app php:8.2-cli php artisan key:generate --force
fi

# Build Docker image
echo -e "${GREEN}📦 Building Docker image...${NC}"
docker build -t rocket-lms-backend:latest .

# Stop existing container if running
if [ "$(docker ps -aq -f name=rocket-lms-backend)" ]; then
    echo -e "${YELLOW}🛑 Stopping existing container...${NC}"
    docker stop rocket-lms-backend || true
    docker rm rocket-lms-backend || true
fi

# Run new container
echo -e "${GREEN}🚀 Starting container...${NC}"
docker run -d \
    --name rocket-lms-backend \
    --restart unless-stopped \
    -p 80:80 \
    -v $(pwd)/storage:/var/www/html/storage \
    -v $(pwd)/bootstrap/cache:/var/www/html/bootstrap/cache \
    --env-file .env \
    rocket-lms-backend:latest

# Wait for container to start
echo -e "${YELLOW}⏳ Waiting for container to start...${NC}"
sleep 10

# Check container status
if [ "$(docker ps -q -f name=rocket-lms-backend)" ]; then
    echo -e "${GREEN}✅ Container is running!${NC}"
    echo -e "${GREEN}📋 Container logs:${NC}"
    docker logs --tail 50 rocket-lms-backend
    echo ""
    echo -e "${GREEN}✅ Deployment completed successfully!${NC}"
    echo -e "${GREEN}🌐 Application should be available at: http://$(hostname -I | awk '{print $1}')${NC}"
else
    echo -e "${RED}❌ Container failed to start. Check logs:${NC}"
    docker logs rocket-lms-backend
    exit 1
fi
